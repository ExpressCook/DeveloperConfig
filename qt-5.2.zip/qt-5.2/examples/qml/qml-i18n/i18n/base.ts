<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" sourcelanguage="en">
<context>
    <name>qml-i18n</name>
    <message>
        <location filename="../qml-i18n.qml" line="56"/>
        <source>Hello</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
